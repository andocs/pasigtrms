<?php
echo '<pre>';
print_r(scandir('.'));
echo '</pre>';
?>
